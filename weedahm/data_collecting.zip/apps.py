from django.apps import AppConfig


class DataCollectingConfig(AppConfig):
    name = 'data_collecting'
